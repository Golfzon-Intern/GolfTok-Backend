package com.golfzon.golftok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GolftokApplication {

	public static void main(String[] args) {
		SpringApplication.run(GolftokApplication.class, args);
	}

}
